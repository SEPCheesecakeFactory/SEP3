# Process Report

This document describes the process of developing the project for the Semester Project 3 (SEP3) course at VIA University College. It outlines the steps taken, challenges faced, and solutions implemented during the project lifecycle.

![Diagram](Figures\diagram.png)