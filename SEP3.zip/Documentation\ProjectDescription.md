# Project Description

This document describes the project for the Semester Project 3 (SEP3) course at VIA University College.

![Diagram](Figures\diagram.png)