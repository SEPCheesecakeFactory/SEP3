using System;

namespace Entities;

public class UserDto
{
    public int Id { get; set; }
    public string Username { get; set; }
}
