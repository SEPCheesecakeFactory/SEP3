namespace RESTAPI.Dtos;

public class CreateLearningStepDto
{
    public string Type { get; set; } = string.Empty;
    public string Content { get; set; } = string.Empty;
    public int CourseId { get; set; }
}