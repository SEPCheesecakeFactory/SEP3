namespace RESTAPI.Dtos;
public class ChangePasswordDto
{
    public string Username { get; set; }
    public string CurrentPassword { get; set; }
    public string NewPassword { get; set; }
}