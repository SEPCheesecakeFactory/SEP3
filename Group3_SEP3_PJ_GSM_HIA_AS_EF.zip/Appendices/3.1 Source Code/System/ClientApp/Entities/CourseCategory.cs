using System;

namespace BlazorApp.Entities;

public class CourseCategory
{
    public int Id { set; get; }
    public string Name { set; get; }
    public string Descritpion{ set; get; }
}
