using System;

namespace BlazorApp.Entities;

public class LoginRequest
{
    public string Username { set; get; }
    public string Password { set; get; }
}
