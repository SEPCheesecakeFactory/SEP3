using System;

namespace BlazorApp.Entities;

public class UserDto
{
    public int Id { set; get; }
    public string Username { set; get; }
}
