using System;

namespace BlazorApp.Entities;

public class Role
{
    public string RoleName { set; get; }
}
