using System;

namespace BlazorApp.Entities;

public class CreateCourseCategoryDto
{
    public string Name { set; get; }
    public string Descritpion{ set; get; }
}
