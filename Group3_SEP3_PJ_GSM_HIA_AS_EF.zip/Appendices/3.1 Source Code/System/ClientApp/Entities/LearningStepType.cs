namespace BlazorApp.Entities;

public class LearningStepType
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
}
