namespace BlazorApp.Entities;

public class LearningStepId
{
    public int StepOrder { get; set; }
    public int CourseId { get; set; }
}
