package via.sep3.dataserver.data;

public interface LeaderboardEntry {
  String getUsername();
  long getTotalScore();
}