package via.sep3.dataserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication public class DataServerApplication
{

  public static void main(String[] args)
  {
    SpringApplication.run(DataServerApplication.class, args);
  }

}
