package via.sep3.dataserver.grpc;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * ----------------------------------------------------------------------------
 *  Course Service
 * ----------------------------------------------------------------------------
 * </pre>
 */
@io.grpc.stub.annotations.GrpcGenerated
public final class CourseServiceGrpc {

  private CourseServiceGrpc() {}

  public static final java.lang.String SERVICE_NAME = "CourseService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.GetCoursesRequest,
      via.sep3.dataserver.grpc.GetCoursesResponse> getGetCoursesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetCourses",
      requestType = via.sep3.dataserver.grpc.GetCoursesRequest.class,
      responseType = via.sep3.dataserver.grpc.GetCoursesResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.GetCoursesRequest,
      via.sep3.dataserver.grpc.GetCoursesResponse> getGetCoursesMethod() {
    io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.GetCoursesRequest, via.sep3.dataserver.grpc.GetCoursesResponse> getGetCoursesMethod;
    if ((getGetCoursesMethod = CourseServiceGrpc.getGetCoursesMethod) == null) {
      synchronized (CourseServiceGrpc.class) {
        if ((getGetCoursesMethod = CourseServiceGrpc.getGetCoursesMethod) == null) {
          CourseServiceGrpc.getGetCoursesMethod = getGetCoursesMethod =
              io.grpc.MethodDescriptor.<via.sep3.dataserver.grpc.GetCoursesRequest, via.sep3.dataserver.grpc.GetCoursesResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetCourses"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.GetCoursesRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.GetCoursesResponse.getDefaultInstance()))
              .setSchemaDescriptor(new CourseServiceMethodDescriptorSupplier("GetCourses"))
              .build();
        }
      }
    }
    return getGetCoursesMethod;
  }

  private static volatile io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.AddCourseRequest,
      via.sep3.dataserver.grpc.AddCourseResponse> getAddCourseMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "AddCourse",
      requestType = via.sep3.dataserver.grpc.AddCourseRequest.class,
      responseType = via.sep3.dataserver.grpc.AddCourseResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.AddCourseRequest,
      via.sep3.dataserver.grpc.AddCourseResponse> getAddCourseMethod() {
    io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.AddCourseRequest, via.sep3.dataserver.grpc.AddCourseResponse> getAddCourseMethod;
    if ((getAddCourseMethod = CourseServiceGrpc.getAddCourseMethod) == null) {
      synchronized (CourseServiceGrpc.class) {
        if ((getAddCourseMethod = CourseServiceGrpc.getAddCourseMethod) == null) {
          CourseServiceGrpc.getAddCourseMethod = getAddCourseMethod =
              io.grpc.MethodDescriptor.<via.sep3.dataserver.grpc.AddCourseRequest, via.sep3.dataserver.grpc.AddCourseResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "AddCourse"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.AddCourseRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.AddCourseResponse.getDefaultInstance()))
              .setSchemaDescriptor(new CourseServiceMethodDescriptorSupplier("AddCourse"))
              .build();
        }
      }
    }
    return getAddCourseMethod;
  }

  private static volatile io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.UpdateCourseRequest,
      via.sep3.dataserver.grpc.UpdateCourseResponse> getUpdateCourseMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateCourse",
      requestType = via.sep3.dataserver.grpc.UpdateCourseRequest.class,
      responseType = via.sep3.dataserver.grpc.UpdateCourseResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.UpdateCourseRequest,
      via.sep3.dataserver.grpc.UpdateCourseResponse> getUpdateCourseMethod() {
    io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.UpdateCourseRequest, via.sep3.dataserver.grpc.UpdateCourseResponse> getUpdateCourseMethod;
    if ((getUpdateCourseMethod = CourseServiceGrpc.getUpdateCourseMethod) == null) {
      synchronized (CourseServiceGrpc.class) {
        if ((getUpdateCourseMethod = CourseServiceGrpc.getUpdateCourseMethod) == null) {
          CourseServiceGrpc.getUpdateCourseMethod = getUpdateCourseMethod =
              io.grpc.MethodDescriptor.<via.sep3.dataserver.grpc.UpdateCourseRequest, via.sep3.dataserver.grpc.UpdateCourseResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "UpdateCourse"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.UpdateCourseRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.UpdateCourseResponse.getDefaultInstance()))
              .setSchemaDescriptor(new CourseServiceMethodDescriptorSupplier("UpdateCourse"))
              .build();
        }
      }
    }
    return getUpdateCourseMethod;
  }

  private static volatile io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.DeleteCourseRequest,
      via.sep3.dataserver.grpc.Empty> getDeleteCourseMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteCourse",
      requestType = via.sep3.dataserver.grpc.DeleteCourseRequest.class,
      responseType = via.sep3.dataserver.grpc.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.DeleteCourseRequest,
      via.sep3.dataserver.grpc.Empty> getDeleteCourseMethod() {
    io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.DeleteCourseRequest, via.sep3.dataserver.grpc.Empty> getDeleteCourseMethod;
    if ((getDeleteCourseMethod = CourseServiceGrpc.getDeleteCourseMethod) == null) {
      synchronized (CourseServiceGrpc.class) {
        if ((getDeleteCourseMethod = CourseServiceGrpc.getDeleteCourseMethod) == null) {
          CourseServiceGrpc.getDeleteCourseMethod = getDeleteCourseMethod =
              io.grpc.MethodDescriptor.<via.sep3.dataserver.grpc.DeleteCourseRequest, via.sep3.dataserver.grpc.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "DeleteCourse"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.DeleteCourseRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new CourseServiceMethodDescriptorSupplier("DeleteCourse"))
              .build();
        }
      }
    }
    return getDeleteCourseMethod;
  }

  private static volatile io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.GetLearningStepRequest,
      via.sep3.dataserver.grpc.GetLearningStepResponse> getGetLearningStepMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetLearningStep",
      requestType = via.sep3.dataserver.grpc.GetLearningStepRequest.class,
      responseType = via.sep3.dataserver.grpc.GetLearningStepResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.GetLearningStepRequest,
      via.sep3.dataserver.grpc.GetLearningStepResponse> getGetLearningStepMethod() {
    io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.GetLearningStepRequest, via.sep3.dataserver.grpc.GetLearningStepResponse> getGetLearningStepMethod;
    if ((getGetLearningStepMethod = CourseServiceGrpc.getGetLearningStepMethod) == null) {
      synchronized (CourseServiceGrpc.class) {
        if ((getGetLearningStepMethod = CourseServiceGrpc.getGetLearningStepMethod) == null) {
          CourseServiceGrpc.getGetLearningStepMethod = getGetLearningStepMethod =
              io.grpc.MethodDescriptor.<via.sep3.dataserver.grpc.GetLearningStepRequest, via.sep3.dataserver.grpc.GetLearningStepResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetLearningStep"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.GetLearningStepRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.GetLearningStepResponse.getDefaultInstance()))
              .setSchemaDescriptor(new CourseServiceMethodDescriptorSupplier("GetLearningStep"))
              .build();
        }
      }
    }
    return getGetLearningStepMethod;
  }

  private static volatile io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.AddLearningStepRequest,
      via.sep3.dataserver.grpc.AddLearningStepResponse> getAddLearningStepMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "AddLearningStep",
      requestType = via.sep3.dataserver.grpc.AddLearningStepRequest.class,
      responseType = via.sep3.dataserver.grpc.AddLearningStepResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.AddLearningStepRequest,
      via.sep3.dataserver.grpc.AddLearningStepResponse> getAddLearningStepMethod() {
    io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.AddLearningStepRequest, via.sep3.dataserver.grpc.AddLearningStepResponse> getAddLearningStepMethod;
    if ((getAddLearningStepMethod = CourseServiceGrpc.getAddLearningStepMethod) == null) {
      synchronized (CourseServiceGrpc.class) {
        if ((getAddLearningStepMethod = CourseServiceGrpc.getAddLearningStepMethod) == null) {
          CourseServiceGrpc.getAddLearningStepMethod = getAddLearningStepMethod =
              io.grpc.MethodDescriptor.<via.sep3.dataserver.grpc.AddLearningStepRequest, via.sep3.dataserver.grpc.AddLearningStepResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "AddLearningStep"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.AddLearningStepRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.AddLearningStepResponse.getDefaultInstance()))
              .setSchemaDescriptor(new CourseServiceMethodDescriptorSupplier("AddLearningStep"))
              .build();
        }
      }
    }
    return getAddLearningStepMethod;
  }

  private static volatile io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.UpdateLearningStepRequest,
      via.sep3.dataserver.grpc.UpdateLearningStepResponse> getUpdateLearningStepMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateLearningStep",
      requestType = via.sep3.dataserver.grpc.UpdateLearningStepRequest.class,
      responseType = via.sep3.dataserver.grpc.UpdateLearningStepResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.UpdateLearningStepRequest,
      via.sep3.dataserver.grpc.UpdateLearningStepResponse> getUpdateLearningStepMethod() {
    io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.UpdateLearningStepRequest, via.sep3.dataserver.grpc.UpdateLearningStepResponse> getUpdateLearningStepMethod;
    if ((getUpdateLearningStepMethod = CourseServiceGrpc.getUpdateLearningStepMethod) == null) {
      synchronized (CourseServiceGrpc.class) {
        if ((getUpdateLearningStepMethod = CourseServiceGrpc.getUpdateLearningStepMethod) == null) {
          CourseServiceGrpc.getUpdateLearningStepMethod = getUpdateLearningStepMethod =
              io.grpc.MethodDescriptor.<via.sep3.dataserver.grpc.UpdateLearningStepRequest, via.sep3.dataserver.grpc.UpdateLearningStepResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "UpdateLearningStep"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.UpdateLearningStepRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.UpdateLearningStepResponse.getDefaultInstance()))
              .setSchemaDescriptor(new CourseServiceMethodDescriptorSupplier("UpdateLearningStep"))
              .build();
        }
      }
    }
    return getUpdateLearningStepMethod;
  }

  private static volatile io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.CreateCategoryRequest,
      via.sep3.dataserver.grpc.CreateCategoryResponse> getCreateCategoryMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateCategory",
      requestType = via.sep3.dataserver.grpc.CreateCategoryRequest.class,
      responseType = via.sep3.dataserver.grpc.CreateCategoryResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.CreateCategoryRequest,
      via.sep3.dataserver.grpc.CreateCategoryResponse> getCreateCategoryMethod() {
    io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.CreateCategoryRequest, via.sep3.dataserver.grpc.CreateCategoryResponse> getCreateCategoryMethod;
    if ((getCreateCategoryMethod = CourseServiceGrpc.getCreateCategoryMethod) == null) {
      synchronized (CourseServiceGrpc.class) {
        if ((getCreateCategoryMethod = CourseServiceGrpc.getCreateCategoryMethod) == null) {
          CourseServiceGrpc.getCreateCategoryMethod = getCreateCategoryMethod =
              io.grpc.MethodDescriptor.<via.sep3.dataserver.grpc.CreateCategoryRequest, via.sep3.dataserver.grpc.CreateCategoryResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateCategory"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.CreateCategoryRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.CreateCategoryResponse.getDefaultInstance()))
              .setSchemaDescriptor(new CourseServiceMethodDescriptorSupplier("CreateCategory"))
              .build();
        }
      }
    }
    return getCreateCategoryMethod;
  }

  private static volatile io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.GetCategoriesRequest,
      via.sep3.dataserver.grpc.GetCategoriesResponse> getGetCategoriesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetCategories",
      requestType = via.sep3.dataserver.grpc.GetCategoriesRequest.class,
      responseType = via.sep3.dataserver.grpc.GetCategoriesResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.GetCategoriesRequest,
      via.sep3.dataserver.grpc.GetCategoriesResponse> getGetCategoriesMethod() {
    io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.GetCategoriesRequest, via.sep3.dataserver.grpc.GetCategoriesResponse> getGetCategoriesMethod;
    if ((getGetCategoriesMethod = CourseServiceGrpc.getGetCategoriesMethod) == null) {
      synchronized (CourseServiceGrpc.class) {
        if ((getGetCategoriesMethod = CourseServiceGrpc.getGetCategoriesMethod) == null) {
          CourseServiceGrpc.getGetCategoriesMethod = getGetCategoriesMethod =
              io.grpc.MethodDescriptor.<via.sep3.dataserver.grpc.GetCategoriesRequest, via.sep3.dataserver.grpc.GetCategoriesResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetCategories"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.GetCategoriesRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.GetCategoriesResponse.getDefaultInstance()))
              .setSchemaDescriptor(new CourseServiceMethodDescriptorSupplier("GetCategories"))
              .build();
        }
      }
    }
    return getGetCategoriesMethod;
  }

  private static volatile io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.CreateLanguageRequest,
      via.sep3.dataserver.grpc.CreateLanguageResponse> getCreateLanguageMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateLanguage",
      requestType = via.sep3.dataserver.grpc.CreateLanguageRequest.class,
      responseType = via.sep3.dataserver.grpc.CreateLanguageResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.CreateLanguageRequest,
      via.sep3.dataserver.grpc.CreateLanguageResponse> getCreateLanguageMethod() {
    io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.CreateLanguageRequest, via.sep3.dataserver.grpc.CreateLanguageResponse> getCreateLanguageMethod;
    if ((getCreateLanguageMethod = CourseServiceGrpc.getCreateLanguageMethod) == null) {
      synchronized (CourseServiceGrpc.class) {
        if ((getCreateLanguageMethod = CourseServiceGrpc.getCreateLanguageMethod) == null) {
          CourseServiceGrpc.getCreateLanguageMethod = getCreateLanguageMethod =
              io.grpc.MethodDescriptor.<via.sep3.dataserver.grpc.CreateLanguageRequest, via.sep3.dataserver.grpc.CreateLanguageResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateLanguage"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.CreateLanguageRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.CreateLanguageResponse.getDefaultInstance()))
              .setSchemaDescriptor(new CourseServiceMethodDescriptorSupplier("CreateLanguage"))
              .build();
        }
      }
    }
    return getCreateLanguageMethod;
  }

  private static volatile io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.GetLanguagesRequest,
      via.sep3.dataserver.grpc.GetLanguagesResponse> getGetLanguagesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetLanguages",
      requestType = via.sep3.dataserver.grpc.GetLanguagesRequest.class,
      responseType = via.sep3.dataserver.grpc.GetLanguagesResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.GetLanguagesRequest,
      via.sep3.dataserver.grpc.GetLanguagesResponse> getGetLanguagesMethod() {
    io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.GetLanguagesRequest, via.sep3.dataserver.grpc.GetLanguagesResponse> getGetLanguagesMethod;
    if ((getGetLanguagesMethod = CourseServiceGrpc.getGetLanguagesMethod) == null) {
      synchronized (CourseServiceGrpc.class) {
        if ((getGetLanguagesMethod = CourseServiceGrpc.getGetLanguagesMethod) == null) {
          CourseServiceGrpc.getGetLanguagesMethod = getGetLanguagesMethod =
              io.grpc.MethodDescriptor.<via.sep3.dataserver.grpc.GetLanguagesRequest, via.sep3.dataserver.grpc.GetLanguagesResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetLanguages"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.GetLanguagesRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.GetLanguagesResponse.getDefaultInstance()))
              .setSchemaDescriptor(new CourseServiceMethodDescriptorSupplier("GetLanguages"))
              .build();
        }
      }
    }
    return getGetLanguagesMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static CourseServiceStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<CourseServiceStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<CourseServiceStub>() {
        @java.lang.Override
        public CourseServiceStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new CourseServiceStub(channel, callOptions);
        }
      };
    return CourseServiceStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports all types of calls on the service
   */
  public static CourseServiceBlockingV2Stub newBlockingV2Stub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<CourseServiceBlockingV2Stub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<CourseServiceBlockingV2Stub>() {
        @java.lang.Override
        public CourseServiceBlockingV2Stub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new CourseServiceBlockingV2Stub(channel, callOptions);
        }
      };
    return CourseServiceBlockingV2Stub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static CourseServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<CourseServiceBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<CourseServiceBlockingStub>() {
        @java.lang.Override
        public CourseServiceBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new CourseServiceBlockingStub(channel, callOptions);
        }
      };
    return CourseServiceBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static CourseServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<CourseServiceFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<CourseServiceFutureStub>() {
        @java.lang.Override
        public CourseServiceFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new CourseServiceFutureStub(channel, callOptions);
        }
      };
    return CourseServiceFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * ----------------------------------------------------------------------------
   *  Course Service
   * ----------------------------------------------------------------------------
   * </pre>
   */
  public interface AsyncService {

    /**
     */
    default void getCourses(via.sep3.dataserver.grpc.GetCoursesRequest request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.GetCoursesResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetCoursesMethod(), responseObserver);
    }

    /**
     */
    default void addCourse(via.sep3.dataserver.grpc.AddCourseRequest request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.AddCourseResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getAddCourseMethod(), responseObserver);
    }

    /**
     */
    default void updateCourse(via.sep3.dataserver.grpc.UpdateCourseRequest request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.UpdateCourseResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpdateCourseMethod(), responseObserver);
    }

    /**
     */
    default void deleteCourse(via.sep3.dataserver.grpc.DeleteCourseRequest request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDeleteCourseMethod(), responseObserver);
    }

    /**
     */
    default void getLearningStep(via.sep3.dataserver.grpc.GetLearningStepRequest request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.GetLearningStepResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetLearningStepMethod(), responseObserver);
    }

    /**
     */
    default void addLearningStep(via.sep3.dataserver.grpc.AddLearningStepRequest request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.AddLearningStepResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getAddLearningStepMethod(), responseObserver);
    }

    /**
     */
    default void updateLearningStep(via.sep3.dataserver.grpc.UpdateLearningStepRequest request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.UpdateLearningStepResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpdateLearningStepMethod(), responseObserver);
    }

    /**
     */
    default void createCategory(via.sep3.dataserver.grpc.CreateCategoryRequest request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.CreateCategoryResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateCategoryMethod(), responseObserver);
    }

    /**
     */
    default void getCategories(via.sep3.dataserver.grpc.GetCategoriesRequest request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.GetCategoriesResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetCategoriesMethod(), responseObserver);
    }

    /**
     */
    default void createLanguage(via.sep3.dataserver.grpc.CreateLanguageRequest request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.CreateLanguageResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateLanguageMethod(), responseObserver);
    }

    /**
     */
    default void getLanguages(via.sep3.dataserver.grpc.GetLanguagesRequest request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.GetLanguagesResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetLanguagesMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service CourseService.
   * <pre>
   * ----------------------------------------------------------------------------
   *  Course Service
   * ----------------------------------------------------------------------------
   * </pre>
   */
  public static abstract class CourseServiceImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return CourseServiceGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service CourseService.
   * <pre>
   * ----------------------------------------------------------------------------
   *  Course Service
   * ----------------------------------------------------------------------------
   * </pre>
   */
  public static final class CourseServiceStub
      extends io.grpc.stub.AbstractAsyncStub<CourseServiceStub> {
    private CourseServiceStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected CourseServiceStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new CourseServiceStub(channel, callOptions);
    }

    /**
     */
    public void getCourses(via.sep3.dataserver.grpc.GetCoursesRequest request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.GetCoursesResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetCoursesMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void addCourse(via.sep3.dataserver.grpc.AddCourseRequest request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.AddCourseResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getAddCourseMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void updateCourse(via.sep3.dataserver.grpc.UpdateCourseRequest request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.UpdateCourseResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpdateCourseMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void deleteCourse(via.sep3.dataserver.grpc.DeleteCourseRequest request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDeleteCourseMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getLearningStep(via.sep3.dataserver.grpc.GetLearningStepRequest request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.GetLearningStepResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetLearningStepMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void addLearningStep(via.sep3.dataserver.grpc.AddLearningStepRequest request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.AddLearningStepResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getAddLearningStepMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void updateLearningStep(via.sep3.dataserver.grpc.UpdateLearningStepRequest request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.UpdateLearningStepResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpdateLearningStepMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void createCategory(via.sep3.dataserver.grpc.CreateCategoryRequest request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.CreateCategoryResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateCategoryMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getCategories(via.sep3.dataserver.grpc.GetCategoriesRequest request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.GetCategoriesResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetCategoriesMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void createLanguage(via.sep3.dataserver.grpc.CreateLanguageRequest request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.CreateLanguageResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateLanguageMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getLanguages(via.sep3.dataserver.grpc.GetLanguagesRequest request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.GetLanguagesResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetLanguagesMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service CourseService.
   * <pre>
   * ----------------------------------------------------------------------------
   *  Course Service
   * ----------------------------------------------------------------------------
   * </pre>
   */
  public static final class CourseServiceBlockingV2Stub
      extends io.grpc.stub.AbstractBlockingStub<CourseServiceBlockingV2Stub> {
    private CourseServiceBlockingV2Stub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected CourseServiceBlockingV2Stub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new CourseServiceBlockingV2Stub(channel, callOptions);
    }

    /**
     */
    public via.sep3.dataserver.grpc.GetCoursesResponse getCourses(via.sep3.dataserver.grpc.GetCoursesRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getGetCoursesMethod(), getCallOptions(), request);
    }

    /**
     */
    public via.sep3.dataserver.grpc.AddCourseResponse addCourse(via.sep3.dataserver.grpc.AddCourseRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getAddCourseMethod(), getCallOptions(), request);
    }

    /**
     */
    public via.sep3.dataserver.grpc.UpdateCourseResponse updateCourse(via.sep3.dataserver.grpc.UpdateCourseRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getUpdateCourseMethod(), getCallOptions(), request);
    }

    /**
     */
    public via.sep3.dataserver.grpc.Empty deleteCourse(via.sep3.dataserver.grpc.DeleteCourseRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getDeleteCourseMethod(), getCallOptions(), request);
    }

    /**
     */
    public via.sep3.dataserver.grpc.GetLearningStepResponse getLearningStep(via.sep3.dataserver.grpc.GetLearningStepRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getGetLearningStepMethod(), getCallOptions(), request);
    }

    /**
     */
    public via.sep3.dataserver.grpc.AddLearningStepResponse addLearningStep(via.sep3.dataserver.grpc.AddLearningStepRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getAddLearningStepMethod(), getCallOptions(), request);
    }

    /**
     */
    public via.sep3.dataserver.grpc.UpdateLearningStepResponse updateLearningStep(via.sep3.dataserver.grpc.UpdateLearningStepRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getUpdateLearningStepMethod(), getCallOptions(), request);
    }

    /**
     */
    public via.sep3.dataserver.grpc.CreateCategoryResponse createCategory(via.sep3.dataserver.grpc.CreateCategoryRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getCreateCategoryMethod(), getCallOptions(), request);
    }

    /**
     */
    public via.sep3.dataserver.grpc.GetCategoriesResponse getCategories(via.sep3.dataserver.grpc.GetCategoriesRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getGetCategoriesMethod(), getCallOptions(), request);
    }

    /**
     */
    public via.sep3.dataserver.grpc.CreateLanguageResponse createLanguage(via.sep3.dataserver.grpc.CreateLanguageRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getCreateLanguageMethod(), getCallOptions(), request);
    }

    /**
     */
    public via.sep3.dataserver.grpc.GetLanguagesResponse getLanguages(via.sep3.dataserver.grpc.GetLanguagesRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getGetLanguagesMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do limited synchronous rpc calls to service CourseService.
   * <pre>
   * ----------------------------------------------------------------------------
   *  Course Service
   * ----------------------------------------------------------------------------
   * </pre>
   */
  public static final class CourseServiceBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<CourseServiceBlockingStub> {
    private CourseServiceBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected CourseServiceBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new CourseServiceBlockingStub(channel, callOptions);
    }

    /**
     */
    public via.sep3.dataserver.grpc.GetCoursesResponse getCourses(via.sep3.dataserver.grpc.GetCoursesRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetCoursesMethod(), getCallOptions(), request);
    }

    /**
     */
    public via.sep3.dataserver.grpc.AddCourseResponse addCourse(via.sep3.dataserver.grpc.AddCourseRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getAddCourseMethod(), getCallOptions(), request);
    }

    /**
     */
    public via.sep3.dataserver.grpc.UpdateCourseResponse updateCourse(via.sep3.dataserver.grpc.UpdateCourseRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateCourseMethod(), getCallOptions(), request);
    }

    /**
     */
    public via.sep3.dataserver.grpc.Empty deleteCourse(via.sep3.dataserver.grpc.DeleteCourseRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteCourseMethod(), getCallOptions(), request);
    }

    /**
     */
    public via.sep3.dataserver.grpc.GetLearningStepResponse getLearningStep(via.sep3.dataserver.grpc.GetLearningStepRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetLearningStepMethod(), getCallOptions(), request);
    }

    /**
     */
    public via.sep3.dataserver.grpc.AddLearningStepResponse addLearningStep(via.sep3.dataserver.grpc.AddLearningStepRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getAddLearningStepMethod(), getCallOptions(), request);
    }

    /**
     */
    public via.sep3.dataserver.grpc.UpdateLearningStepResponse updateLearningStep(via.sep3.dataserver.grpc.UpdateLearningStepRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateLearningStepMethod(), getCallOptions(), request);
    }

    /**
     */
    public via.sep3.dataserver.grpc.CreateCategoryResponse createCategory(via.sep3.dataserver.grpc.CreateCategoryRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateCategoryMethod(), getCallOptions(), request);
    }

    /**
     */
    public via.sep3.dataserver.grpc.GetCategoriesResponse getCategories(via.sep3.dataserver.grpc.GetCategoriesRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetCategoriesMethod(), getCallOptions(), request);
    }

    /**
     */
    public via.sep3.dataserver.grpc.CreateLanguageResponse createLanguage(via.sep3.dataserver.grpc.CreateLanguageRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateLanguageMethod(), getCallOptions(), request);
    }

    /**
     */
    public via.sep3.dataserver.grpc.GetLanguagesResponse getLanguages(via.sep3.dataserver.grpc.GetLanguagesRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetLanguagesMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service CourseService.
   * <pre>
   * ----------------------------------------------------------------------------
   *  Course Service
   * ----------------------------------------------------------------------------
   * </pre>
   */
  public static final class CourseServiceFutureStub
      extends io.grpc.stub.AbstractFutureStub<CourseServiceFutureStub> {
    private CourseServiceFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected CourseServiceFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new CourseServiceFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<via.sep3.dataserver.grpc.GetCoursesResponse> getCourses(
        via.sep3.dataserver.grpc.GetCoursesRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetCoursesMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<via.sep3.dataserver.grpc.AddCourseResponse> addCourse(
        via.sep3.dataserver.grpc.AddCourseRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getAddCourseMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<via.sep3.dataserver.grpc.UpdateCourseResponse> updateCourse(
        via.sep3.dataserver.grpc.UpdateCourseRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpdateCourseMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<via.sep3.dataserver.grpc.Empty> deleteCourse(
        via.sep3.dataserver.grpc.DeleteCourseRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDeleteCourseMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<via.sep3.dataserver.grpc.GetLearningStepResponse> getLearningStep(
        via.sep3.dataserver.grpc.GetLearningStepRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetLearningStepMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<via.sep3.dataserver.grpc.AddLearningStepResponse> addLearningStep(
        via.sep3.dataserver.grpc.AddLearningStepRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getAddLearningStepMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<via.sep3.dataserver.grpc.UpdateLearningStepResponse> updateLearningStep(
        via.sep3.dataserver.grpc.UpdateLearningStepRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpdateLearningStepMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<via.sep3.dataserver.grpc.CreateCategoryResponse> createCategory(
        via.sep3.dataserver.grpc.CreateCategoryRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateCategoryMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<via.sep3.dataserver.grpc.GetCategoriesResponse> getCategories(
        via.sep3.dataserver.grpc.GetCategoriesRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetCategoriesMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<via.sep3.dataserver.grpc.CreateLanguageResponse> createLanguage(
        via.sep3.dataserver.grpc.CreateLanguageRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateLanguageMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<via.sep3.dataserver.grpc.GetLanguagesResponse> getLanguages(
        via.sep3.dataserver.grpc.GetLanguagesRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetLanguagesMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_GET_COURSES = 0;
  private static final int METHODID_ADD_COURSE = 1;
  private static final int METHODID_UPDATE_COURSE = 2;
  private static final int METHODID_DELETE_COURSE = 3;
  private static final int METHODID_GET_LEARNING_STEP = 4;
  private static final int METHODID_ADD_LEARNING_STEP = 5;
  private static final int METHODID_UPDATE_LEARNING_STEP = 6;
  private static final int METHODID_CREATE_CATEGORY = 7;
  private static final int METHODID_GET_CATEGORIES = 8;
  private static final int METHODID_CREATE_LANGUAGE = 9;
  private static final int METHODID_GET_LANGUAGES = 10;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_GET_COURSES:
          serviceImpl.getCourses((via.sep3.dataserver.grpc.GetCoursesRequest) request,
              (io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.GetCoursesResponse>) responseObserver);
          break;
        case METHODID_ADD_COURSE:
          serviceImpl.addCourse((via.sep3.dataserver.grpc.AddCourseRequest) request,
              (io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.AddCourseResponse>) responseObserver);
          break;
        case METHODID_UPDATE_COURSE:
          serviceImpl.updateCourse((via.sep3.dataserver.grpc.UpdateCourseRequest) request,
              (io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.UpdateCourseResponse>) responseObserver);
          break;
        case METHODID_DELETE_COURSE:
          serviceImpl.deleteCourse((via.sep3.dataserver.grpc.DeleteCourseRequest) request,
              (io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.Empty>) responseObserver);
          break;
        case METHODID_GET_LEARNING_STEP:
          serviceImpl.getLearningStep((via.sep3.dataserver.grpc.GetLearningStepRequest) request,
              (io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.GetLearningStepResponse>) responseObserver);
          break;
        case METHODID_ADD_LEARNING_STEP:
          serviceImpl.addLearningStep((via.sep3.dataserver.grpc.AddLearningStepRequest) request,
              (io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.AddLearningStepResponse>) responseObserver);
          break;
        case METHODID_UPDATE_LEARNING_STEP:
          serviceImpl.updateLearningStep((via.sep3.dataserver.grpc.UpdateLearningStepRequest) request,
              (io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.UpdateLearningStepResponse>) responseObserver);
          break;
        case METHODID_CREATE_CATEGORY:
          serviceImpl.createCategory((via.sep3.dataserver.grpc.CreateCategoryRequest) request,
              (io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.CreateCategoryResponse>) responseObserver);
          break;
        case METHODID_GET_CATEGORIES:
          serviceImpl.getCategories((via.sep3.dataserver.grpc.GetCategoriesRequest) request,
              (io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.GetCategoriesResponse>) responseObserver);
          break;
        case METHODID_CREATE_LANGUAGE:
          serviceImpl.createLanguage((via.sep3.dataserver.grpc.CreateLanguageRequest) request,
              (io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.CreateLanguageResponse>) responseObserver);
          break;
        case METHODID_GET_LANGUAGES:
          serviceImpl.getLanguages((via.sep3.dataserver.grpc.GetLanguagesRequest) request,
              (io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.GetLanguagesResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getGetCoursesMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              via.sep3.dataserver.grpc.GetCoursesRequest,
              via.sep3.dataserver.grpc.GetCoursesResponse>(
                service, METHODID_GET_COURSES)))
        .addMethod(
          getAddCourseMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              via.sep3.dataserver.grpc.AddCourseRequest,
              via.sep3.dataserver.grpc.AddCourseResponse>(
                service, METHODID_ADD_COURSE)))
        .addMethod(
          getUpdateCourseMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              via.sep3.dataserver.grpc.UpdateCourseRequest,
              via.sep3.dataserver.grpc.UpdateCourseResponse>(
                service, METHODID_UPDATE_COURSE)))
        .addMethod(
          getDeleteCourseMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              via.sep3.dataserver.grpc.DeleteCourseRequest,
              via.sep3.dataserver.grpc.Empty>(
                service, METHODID_DELETE_COURSE)))
        .addMethod(
          getGetLearningStepMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              via.sep3.dataserver.grpc.GetLearningStepRequest,
              via.sep3.dataserver.grpc.GetLearningStepResponse>(
                service, METHODID_GET_LEARNING_STEP)))
        .addMethod(
          getAddLearningStepMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              via.sep3.dataserver.grpc.AddLearningStepRequest,
              via.sep3.dataserver.grpc.AddLearningStepResponse>(
                service, METHODID_ADD_LEARNING_STEP)))
        .addMethod(
          getUpdateLearningStepMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              via.sep3.dataserver.grpc.UpdateLearningStepRequest,
              via.sep3.dataserver.grpc.UpdateLearningStepResponse>(
                service, METHODID_UPDATE_LEARNING_STEP)))
        .addMethod(
          getCreateCategoryMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              via.sep3.dataserver.grpc.CreateCategoryRequest,
              via.sep3.dataserver.grpc.CreateCategoryResponse>(
                service, METHODID_CREATE_CATEGORY)))
        .addMethod(
          getGetCategoriesMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              via.sep3.dataserver.grpc.GetCategoriesRequest,
              via.sep3.dataserver.grpc.GetCategoriesResponse>(
                service, METHODID_GET_CATEGORIES)))
        .addMethod(
          getCreateLanguageMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              via.sep3.dataserver.grpc.CreateLanguageRequest,
              via.sep3.dataserver.grpc.CreateLanguageResponse>(
                service, METHODID_CREATE_LANGUAGE)))
        .addMethod(
          getGetLanguagesMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              via.sep3.dataserver.grpc.GetLanguagesRequest,
              via.sep3.dataserver.grpc.GetLanguagesResponse>(
                service, METHODID_GET_LANGUAGES)))
        .build();
  }

  private static abstract class CourseServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    CourseServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return via.sep3.dataserver.grpc.DataProtocol.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("CourseService");
    }
  }

  private static final class CourseServiceFileDescriptorSupplier
      extends CourseServiceBaseDescriptorSupplier {
    CourseServiceFileDescriptorSupplier() {}
  }

  private static final class CourseServiceMethodDescriptorSupplier
      extends CourseServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    CourseServiceMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (CourseServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new CourseServiceFileDescriptorSupplier())
              .addMethod(getGetCoursesMethod())
              .addMethod(getAddCourseMethod())
              .addMethod(getUpdateCourseMethod())
              .addMethod(getDeleteCourseMethod())
              .addMethod(getGetLearningStepMethod())
              .addMethod(getAddLearningStepMethod())
              .addMethod(getUpdateLearningStepMethod())
              .addMethod(getCreateCategoryMethod())
              .addMethod(getGetCategoriesMethod())
              .addMethod(getCreateLanguageMethod())
              .addMethod(getGetLanguagesMethod())
              .build();
        }
      }
    }
    return result;
  }
}
