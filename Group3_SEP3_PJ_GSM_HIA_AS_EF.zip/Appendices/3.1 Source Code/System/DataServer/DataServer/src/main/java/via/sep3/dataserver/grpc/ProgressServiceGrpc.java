package via.sep3.dataserver.grpc;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * ----------------------------------------------------------------------------
 *  Progress Service
 * ----------------------------------------------------------------------------
 * </pre>
 */
@io.grpc.stub.annotations.GrpcGenerated
public final class ProgressServiceGrpc {

  private ProgressServiceGrpc() {}

  public static final java.lang.String SERVICE_NAME = "ProgressService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.CourseProgressRequest,
      via.sep3.dataserver.grpc.CourseProgressResponse> getGetCourseProgressMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetCourseProgress",
      requestType = via.sep3.dataserver.grpc.CourseProgressRequest.class,
      responseType = via.sep3.dataserver.grpc.CourseProgressResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.CourseProgressRequest,
      via.sep3.dataserver.grpc.CourseProgressResponse> getGetCourseProgressMethod() {
    io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.CourseProgressRequest, via.sep3.dataserver.grpc.CourseProgressResponse> getGetCourseProgressMethod;
    if ((getGetCourseProgressMethod = ProgressServiceGrpc.getGetCourseProgressMethod) == null) {
      synchronized (ProgressServiceGrpc.class) {
        if ((getGetCourseProgressMethod = ProgressServiceGrpc.getGetCourseProgressMethod) == null) {
          ProgressServiceGrpc.getGetCourseProgressMethod = getGetCourseProgressMethod =
              io.grpc.MethodDescriptor.<via.sep3.dataserver.grpc.CourseProgressRequest, via.sep3.dataserver.grpc.CourseProgressResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetCourseProgress"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.CourseProgressRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.CourseProgressResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ProgressServiceMethodDescriptorSupplier("GetCourseProgress"))
              .build();
        }
      }
    }
    return getGetCourseProgressMethod;
  }

  private static volatile io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.CourseProgressUpdate,
      via.sep3.dataserver.grpc.Empty> getUpdateCourseProgressMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateCourseProgress",
      requestType = via.sep3.dataserver.grpc.CourseProgressUpdate.class,
      responseType = via.sep3.dataserver.grpc.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.CourseProgressUpdate,
      via.sep3.dataserver.grpc.Empty> getUpdateCourseProgressMethod() {
    io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.CourseProgressUpdate, via.sep3.dataserver.grpc.Empty> getUpdateCourseProgressMethod;
    if ((getUpdateCourseProgressMethod = ProgressServiceGrpc.getUpdateCourseProgressMethod) == null) {
      synchronized (ProgressServiceGrpc.class) {
        if ((getUpdateCourseProgressMethod = ProgressServiceGrpc.getUpdateCourseProgressMethod) == null) {
          ProgressServiceGrpc.getUpdateCourseProgressMethod = getUpdateCourseProgressMethod =
              io.grpc.MethodDescriptor.<via.sep3.dataserver.grpc.CourseProgressUpdate, via.sep3.dataserver.grpc.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "UpdateCourseProgress"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.CourseProgressUpdate.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new ProgressServiceMethodDescriptorSupplier("UpdateCourseProgress"))
              .build();
        }
      }
    }
    return getUpdateCourseProgressMethod;
  }

  private static volatile io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.Empty,
      via.sep3.dataserver.grpc.GetLeaderboardResponse> getGetLeaderboardMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetLeaderboard",
      requestType = via.sep3.dataserver.grpc.Empty.class,
      responseType = via.sep3.dataserver.grpc.GetLeaderboardResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.Empty,
      via.sep3.dataserver.grpc.GetLeaderboardResponse> getGetLeaderboardMethod() {
    io.grpc.MethodDescriptor<via.sep3.dataserver.grpc.Empty, via.sep3.dataserver.grpc.GetLeaderboardResponse> getGetLeaderboardMethod;
    if ((getGetLeaderboardMethod = ProgressServiceGrpc.getGetLeaderboardMethod) == null) {
      synchronized (ProgressServiceGrpc.class) {
        if ((getGetLeaderboardMethod = ProgressServiceGrpc.getGetLeaderboardMethod) == null) {
          ProgressServiceGrpc.getGetLeaderboardMethod = getGetLeaderboardMethod =
              io.grpc.MethodDescriptor.<via.sep3.dataserver.grpc.Empty, via.sep3.dataserver.grpc.GetLeaderboardResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetLeaderboard"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.Empty.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  via.sep3.dataserver.grpc.GetLeaderboardResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ProgressServiceMethodDescriptorSupplier("GetLeaderboard"))
              .build();
        }
      }
    }
    return getGetLeaderboardMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static ProgressServiceStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ProgressServiceStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ProgressServiceStub>() {
        @java.lang.Override
        public ProgressServiceStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ProgressServiceStub(channel, callOptions);
        }
      };
    return ProgressServiceStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports all types of calls on the service
   */
  public static ProgressServiceBlockingV2Stub newBlockingV2Stub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ProgressServiceBlockingV2Stub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ProgressServiceBlockingV2Stub>() {
        @java.lang.Override
        public ProgressServiceBlockingV2Stub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ProgressServiceBlockingV2Stub(channel, callOptions);
        }
      };
    return ProgressServiceBlockingV2Stub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static ProgressServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ProgressServiceBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ProgressServiceBlockingStub>() {
        @java.lang.Override
        public ProgressServiceBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ProgressServiceBlockingStub(channel, callOptions);
        }
      };
    return ProgressServiceBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static ProgressServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ProgressServiceFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ProgressServiceFutureStub>() {
        @java.lang.Override
        public ProgressServiceFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ProgressServiceFutureStub(channel, callOptions);
        }
      };
    return ProgressServiceFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * ----------------------------------------------------------------------------
   *  Progress Service
   * ----------------------------------------------------------------------------
   * </pre>
   */
  public interface AsyncService {

    /**
     */
    default void getCourseProgress(via.sep3.dataserver.grpc.CourseProgressRequest request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.CourseProgressResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetCourseProgressMethod(), responseObserver);
    }

    /**
     */
    default void updateCourseProgress(via.sep3.dataserver.grpc.CourseProgressUpdate request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpdateCourseProgressMethod(), responseObserver);
    }

    /**
     */
    default void getLeaderboard(via.sep3.dataserver.grpc.Empty request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.GetLeaderboardResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetLeaderboardMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service ProgressService.
   * <pre>
   * ----------------------------------------------------------------------------
   *  Progress Service
   * ----------------------------------------------------------------------------
   * </pre>
   */
  public static abstract class ProgressServiceImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return ProgressServiceGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service ProgressService.
   * <pre>
   * ----------------------------------------------------------------------------
   *  Progress Service
   * ----------------------------------------------------------------------------
   * </pre>
   */
  public static final class ProgressServiceStub
      extends io.grpc.stub.AbstractAsyncStub<ProgressServiceStub> {
    private ProgressServiceStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ProgressServiceStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ProgressServiceStub(channel, callOptions);
    }

    /**
     */
    public void getCourseProgress(via.sep3.dataserver.grpc.CourseProgressRequest request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.CourseProgressResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetCourseProgressMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void updateCourseProgress(via.sep3.dataserver.grpc.CourseProgressUpdate request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpdateCourseProgressMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getLeaderboard(via.sep3.dataserver.grpc.Empty request,
        io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.GetLeaderboardResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetLeaderboardMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service ProgressService.
   * <pre>
   * ----------------------------------------------------------------------------
   *  Progress Service
   * ----------------------------------------------------------------------------
   * </pre>
   */
  public static final class ProgressServiceBlockingV2Stub
      extends io.grpc.stub.AbstractBlockingStub<ProgressServiceBlockingV2Stub> {
    private ProgressServiceBlockingV2Stub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ProgressServiceBlockingV2Stub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ProgressServiceBlockingV2Stub(channel, callOptions);
    }

    /**
     */
    public via.sep3.dataserver.grpc.CourseProgressResponse getCourseProgress(via.sep3.dataserver.grpc.CourseProgressRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getGetCourseProgressMethod(), getCallOptions(), request);
    }

    /**
     */
    public via.sep3.dataserver.grpc.Empty updateCourseProgress(via.sep3.dataserver.grpc.CourseProgressUpdate request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getUpdateCourseProgressMethod(), getCallOptions(), request);
    }

    /**
     */
    public via.sep3.dataserver.grpc.GetLeaderboardResponse getLeaderboard(via.sep3.dataserver.grpc.Empty request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getGetLeaderboardMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do limited synchronous rpc calls to service ProgressService.
   * <pre>
   * ----------------------------------------------------------------------------
   *  Progress Service
   * ----------------------------------------------------------------------------
   * </pre>
   */
  public static final class ProgressServiceBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<ProgressServiceBlockingStub> {
    private ProgressServiceBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ProgressServiceBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ProgressServiceBlockingStub(channel, callOptions);
    }

    /**
     */
    public via.sep3.dataserver.grpc.CourseProgressResponse getCourseProgress(via.sep3.dataserver.grpc.CourseProgressRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetCourseProgressMethod(), getCallOptions(), request);
    }

    /**
     */
    public via.sep3.dataserver.grpc.Empty updateCourseProgress(via.sep3.dataserver.grpc.CourseProgressUpdate request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateCourseProgressMethod(), getCallOptions(), request);
    }

    /**
     */
    public via.sep3.dataserver.grpc.GetLeaderboardResponse getLeaderboard(via.sep3.dataserver.grpc.Empty request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetLeaderboardMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service ProgressService.
   * <pre>
   * ----------------------------------------------------------------------------
   *  Progress Service
   * ----------------------------------------------------------------------------
   * </pre>
   */
  public static final class ProgressServiceFutureStub
      extends io.grpc.stub.AbstractFutureStub<ProgressServiceFutureStub> {
    private ProgressServiceFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ProgressServiceFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ProgressServiceFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<via.sep3.dataserver.grpc.CourseProgressResponse> getCourseProgress(
        via.sep3.dataserver.grpc.CourseProgressRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetCourseProgressMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<via.sep3.dataserver.grpc.Empty> updateCourseProgress(
        via.sep3.dataserver.grpc.CourseProgressUpdate request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpdateCourseProgressMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<via.sep3.dataserver.grpc.GetLeaderboardResponse> getLeaderboard(
        via.sep3.dataserver.grpc.Empty request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetLeaderboardMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_GET_COURSE_PROGRESS = 0;
  private static final int METHODID_UPDATE_COURSE_PROGRESS = 1;
  private static final int METHODID_GET_LEADERBOARD = 2;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_GET_COURSE_PROGRESS:
          serviceImpl.getCourseProgress((via.sep3.dataserver.grpc.CourseProgressRequest) request,
              (io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.CourseProgressResponse>) responseObserver);
          break;
        case METHODID_UPDATE_COURSE_PROGRESS:
          serviceImpl.updateCourseProgress((via.sep3.dataserver.grpc.CourseProgressUpdate) request,
              (io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.Empty>) responseObserver);
          break;
        case METHODID_GET_LEADERBOARD:
          serviceImpl.getLeaderboard((via.sep3.dataserver.grpc.Empty) request,
              (io.grpc.stub.StreamObserver<via.sep3.dataserver.grpc.GetLeaderboardResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getGetCourseProgressMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              via.sep3.dataserver.grpc.CourseProgressRequest,
              via.sep3.dataserver.grpc.CourseProgressResponse>(
                service, METHODID_GET_COURSE_PROGRESS)))
        .addMethod(
          getUpdateCourseProgressMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              via.sep3.dataserver.grpc.CourseProgressUpdate,
              via.sep3.dataserver.grpc.Empty>(
                service, METHODID_UPDATE_COURSE_PROGRESS)))
        .addMethod(
          getGetLeaderboardMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              via.sep3.dataserver.grpc.Empty,
              via.sep3.dataserver.grpc.GetLeaderboardResponse>(
                service, METHODID_GET_LEADERBOARD)))
        .build();
  }

  private static abstract class ProgressServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    ProgressServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return via.sep3.dataserver.grpc.DataProtocol.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("ProgressService");
    }
  }

  private static final class ProgressServiceFileDescriptorSupplier
      extends ProgressServiceBaseDescriptorSupplier {
    ProgressServiceFileDescriptorSupplier() {}
  }

  private static final class ProgressServiceMethodDescriptorSupplier
      extends ProgressServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    ProgressServiceMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (ProgressServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new ProgressServiceFileDescriptorSupplier())
              .addMethod(getGetCourseProgressMethod())
              .addMethod(getUpdateCourseProgressMethod())
              .addMethod(getGetLeaderboardMethod())
              .build();
        }
      }
    }
    return result;
  }
}
