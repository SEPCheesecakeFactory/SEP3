package via.sep3.dataserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest class DataServerApplicationTests
{

  @Test void contextLoads()
  {
  }

}
